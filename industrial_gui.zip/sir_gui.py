import tkinter as tk
from tkinter import font  as tkfont
import PIL
import threading
from threading import Timer
from PIL import Image,ImageTk, ImageSequence
from tkinter import messagebox, Label
import time
LARGE_FONT= ("Verdana", 12)
import RPi.GPIO as GPIO
import time
import tksheet
import datetime
import os
import smbus  
import time
import struct
import sys


bus = smbus.SMBus(1)  

address_1 = 0x03              # Arduino I2C Address  
address_2 = 0x04

smsMessage_1=""
smsMessage_2=""

global text_1, text_2


GPIO.setmode (GPIO.BCM)
GPIO.setwarnings(False)



class RepeatedTimer(object):
    def __init__(self, interval, function, *args, **kwargs):
        self._timer     = None
        self.interval   = interval
        self.function   = function
        self.args       = args
        self.kwargs     = kwargs
        self.is_running = False
        self.start()

    def _run(self):
        self.is_running = False
        self.start()
        self.function(*self.args, **self.kwargs)

    def start(self):
        if not self.is_running:
            self._timer = Timer(self.interval, self._run)
            self._timer.start()
            self.is_running = True

    def stop(self):
        self._timer.cancel()
        self.is_running = False





class CarGUI(tk.Tk):

    def __init__(self, *args, **kwargs):

        tk.Tk.__init__(self, *args, **kwargs)

        self.title_font = tkfont.Font(family='Helvetica', size=18, weight="bold", slant="italic")
        self.attributes("-fullscreen",True)


        container = tk.Frame(self)

        container.pack(side="top", fill="both", expand = True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (StartPage, PageOne, PageTwo):

            frame = F(container, self)

            self.frames[F] = frame

            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(StartPage)

    def show_frame(self, cont):

        frame = self.frames[cont]
        frame.tkraise()


class StartPage(tk.Frame):


    def goTopageOne(self,data=None):
        self.controller.show_frame("PageOne")


    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        self.controller = controller

        global button_script, canvas, i, canvas3
        i = 1

        canvas = tk.Canvas(self, bg= "black", width=1024,height=600)
        canvas.pack(fill=tk.BOTH, expand=tk.YES)
        
        canvas2 = tk.Canvas(canvas, bg= "black", width=800,height=700)
        canvas2.place(x=48, y=120)
        
        
        def values_initializer(self):
            #This will hold each and every readings
            print("All to be saved values")
        
        
        def fetch_tv(self=self):
            print("ABC")
            '''
            global x, text_1, text_2
            date = datetime.datetime.now().strftime('%d-%m-%Y, %I:%M %p')
            print(date)
            lst[1][1]=text_1
            lst[1][2]=text_2
            for i in range(6):
                for j in range(5):
                    e = tk.Entry(canvas2, width=25, bd=3, fg='blue', justify=tk.CENTER, relief=tk.RIDGE, font=('Times',11,'bold')) 
                    e.grid(row=i, column=j, ipady=20)
                    e.insert(tk.END, lst[i][j])
                    if i==0:
                        e.config(fg='black', font=('Calibri',11,'bold'),bg='light green')
                    if j==0 and i>0:
                        e.config(fg='white', bg='black')
            '''


            
        

        def func_button_one(self):
            global i, canvas3

            if i%2==0:
                canvas3 = tk.Canvas(canvas2, bg="black", width=922,height=402)
                canvas3.place(x=0,y=0)
                canvas3.create_text(460,90,fill="light blue",font="Times 50 bold italic",text="System Under Maintainance")
                maintain = Image.open('/home/pi/maintain.png')
                canvas3.image_maintain =ImageTk.PhotoImage(maintain)
                maintain = canvas3.create_image(370,170, image=canvas3.image_maintain, anchor='nw')

                canvas.itemconfigure(on_1, fill='white')
                canvas.itemconfigure(off_1, fill='white')
                canvas.itemconfigure(button_script, text="Start...")
                



            else:
                canvas.itemconfigure(on_1, fill='red')
                canvas.itemconfigure(off_1, fill='yellow')
                canvas.itemconfigure(button_script, text="Running", font="Arial 36 bold")
                canvas3.destroy()
                

            i+=1


        button_1 = Image.open('/home/pi/line_2.png')
        canvas.image_button_1 =ImageTk.PhotoImage(button_1)
        button_1 = canvas.create_image(250,580, image=canvas.image_button_1, anchor='nw')

        on_1 = canvas.create_oval(365, 600, 390, 625, fill='white', width=1)
        off_1 = canvas.create_oval(415, 600, 438, 625, fill='white', width=1)
        

        
        head = canvas.create_text(499,60,fill="white",font="Times 45 bold",text="EASTERN GARMENTS")

        button_script = canvas.create_text(37,580, text="Start...", font="Arial 40 bold",fill="#FFFFFF", anchor='nw')

        canvas.create_text(20,710, text="Designed By: PakMeters®", font="Arial 20 bold",fill="#FFFFFF", anchor='nw')
        global x
        x = tk.StringVar()


        upd_butt = Image.open('/home/pi/upd.png')
        canvas.image_upd_butt =ImageTk.PhotoImage(upd_butt)
        upd_butt = canvas.create_image(580,570, image=canvas.image_upd_butt, anchor='nw')
        

        lst = [['Meter Name','Current Value (m³)','Date & Time (Current)','Previous Value (m³)','Date & Time(Previous)',0],
               ['Water Meter # 1',3,'','','','',''],
               ['Water Meter # 2','','','','','',''],
               ['Water Meter # 3','','','','','',''],
               ['Water Meter # 4','','','','','',''],
               ['Water Meter # 5','','','','','','']]
        

        for i in range(6): 
            for j in range(5):                    
                e = tk.Entry(canvas2, width=25, bd=3, fg='blue', justify=tk.CENTER, relief=tk.RIDGE, font=('Times',11,'bold')) 
                e.grid(row=i, column=j, ipady=20)
                e.insert(tk.END, lst[i][j])
                if i==0:
                    e.config(fg='black', font=('Calibri',11,'bold'),bg='light green')
                if j==0 and i>0:
                    e.config(fg='white', bg='black')
                    
        canvas3 = tk.Canvas(canvas2, bg="black", width=922,height=402)
        canvas3.place(x=0,y=0)
        canvas3.create_text(460,90,fill="light blue",font="Times 50 bold italic",text="System Under Maintainance")

        maintain = Image.open('/home/pi/maintain.png')
        canvas3.image_maintain =ImageTk.PhotoImage(maintain)
        maintain = canvas3.create_image(370,170, image=canvas3.image_maintain, anchor='nw')




        canvas.tag_bind(button_1, "<Button-1>",func_button_one)
        canvas.tag_bind(upd_butt,"<Button-1>",fetch_tv)
        rt = RepeatedTimer(20, fetch_tv)
        


class PageOne(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

    def goTopageTwo(self,data=None):
        self.controller.show_frame("PageTwo")





class PageTwo(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)


class myThread (threading.Thread):
    def run(self):
        global text_1, text_2, text3, forw, backw, climate
        i2cData = False 
        while 1:
            i2cData = not i2cData
            global smsMessage_1, smsMessage_2
            
            data_received_from_Arduino_1 = bus.read_i2c_block_data(address_1,0x00,9)
            data_received_from_Arduino_2 = bus.read_i2c_block_data(address_2,0x00,9)
            
            for i in range(len(data_received_from_Arduino_1)):
                smsMessage_1 += chr(data_received_from_Arduino_1[i])
                text_1 = smsMessage_1.encode('utf-8').decode('utf-8')
            print(smsMessage_1.encode('utf-8').decode('utf-8'))
            print("\n")
            smsMessage_1=""
            
        

            for i in range(len(data_received_from_Arduino_2)):
                smsMessage_2 += chr(data_received_from_Arduino_2[i])
                text_2 = smsMessage_2.encode('utf-8').decode('utf-8')
            print(smsMessage_2.encode('utf-8').decode('utf-8'))
            print("\n")
            smsMessage_2=""
        
          
            time.sleep(1)
        

            


if __name__ == "__main__":
    try:
        thread1 = myThread()
        #thread1.start()
        app = CarGUI()
        app.mainloop()
    except KeyboardInterrupt:  
        GPIO.cleanup()  
        sys.exit(0)

    