from time import sleep

a = 3
b = 7

print(a+b)