from time import sleep

print("We are testing the time library in Python")

sleep(10)

print("Now you're allowed to print the second line")