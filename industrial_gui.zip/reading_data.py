import smbus  
import time  
import sys
import struct
bus = smbus.SMBus(1)  
address_1 = 0x03              # Arduino I2C Address  
address_2 = 0x04

smsMessage_1=""
smsMessage_2=""


def main():
    
    i2cData = False  
    while 1:  
        # send data  
        i2cData = not i2cData  
        global smsMessage_1, smsMessage_2
        
        
        
        data_received_from_Arduino_1 = bus.read_i2c_block_data(address_1,0x00,9)       
        data_received_from_Arduino_2 = bus.read_i2c_block_data(address_2,0x00,9)
        
        
        for i in range(len(data_received_from_Arduino_1)):
            smsMessage_1 += chr(data_received_from_Arduino_1[i])
        print(smsMessage_1.encode('utf-8').decode('utf-8'))
        print("\n")
        smsMessage_1=""
            
        

        for i in range(len(data_received_from_Arduino_2)):
            smsMessage_2 += chr(data_received_from_Arduino_2[i])
        print(smsMessage_2.encode('utf-8').decode('utf-8'))
        print("\n")
        smsMessage_2=""
        
          
        time.sleep(1)
        
        
if __name__ == '__main__':  
    try:  
        main()  
    except KeyboardInterrupt:  
        gpio.cleanup()  
        sys.exit(0)

